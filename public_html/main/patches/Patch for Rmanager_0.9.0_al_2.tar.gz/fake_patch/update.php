<?php

class UpdatePlugin implements PluginUpdateInterface
{
	public static $_SQL_DATA = array();
	public static $_SQL_PTABLES = array();
	public static $PLUGIN_NAME = 'rmanager';
	
    public static function init()
    {
		// do nothing
        return true;
    }


}

?>

